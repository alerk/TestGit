#include <vector>

int solution(std::vector<int>& A);

#include <vector>
struct IntList {
    int value;
    IntList * next;
};

int solution(IntList * L);

#include "ref_test2.h"

int solution(IntList * L) {
    // TODO:

    return 1;
}

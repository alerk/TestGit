#include "ref_test3.h"

int solution(std::vector<int>& A) {
    // TODO:

    return 1;
}